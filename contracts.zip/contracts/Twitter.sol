// SPDX-License-Identifier: MIT

pragma solidity ^0.8.26;

// 1. Create a Twitter Contract
// 2. Create a mapping between user and tweet
// 3. Add function to create a tweet and save it in mapping
// 4. Create a function to get Tweet

contract Twitter {

    //define our struct

    uint16 public MAX_TWEET_LENGTH = 280;

    struct Tweet {
        uint256 id;
        address author;
        string content;
        uint256 timestamp;
        uint256 likes;
    }

    //add our code
    mapping (address => Tweet[]) public tweets;
    address public owner;

    constructor() {
        owner = msg.sender;
    }

    modifier onlyOwner{
        require(msg.sender == owner, "You are not the owner");
        _;
    }

    function changeTweetLength(uint16 newTweetLength) public onlyOwner {
        //set max tweet length to 280
         MAX_TWEET_LENGTH = newTweetLength;
    }
    
    function createTweet(string memory _tweet) public {
        //conditional
        // if tweet length <= 280 then we are good, otherwise we revert
        require(bytes(_tweet).length <= MAX_TWEET_LENGTH, "You can not tweet that long");





        Tweet memory newTweet = Tweet({
            id: tweets[msg.sender].length,
            author: msg.sender,
            content: _tweet, 
            timestamp: block.timestamp, //get the current time
            likes: 0
        });
        tweets[msg.sender].push(newTweet);
    }

    function likeTweet(address author, uint256 id) external { //like function for tweet id and author
        require(tweets[author][id].id == id,"Tweet does not exist");
        
        tweets[author][id].likes ++;

        
    }

    function unlikeTweet(address author, uint256 id) external { //like function for tweet id and author
        require(tweets[author][id].id == id,"Tweet does not exist");
        require(tweets[author][id].likes > 0,"There are no likes");
        tweets[author][id].likes --;

        
    }

    function getTweet(uint _i) public view returns (Tweet memory) {
        return tweets[msg.sender] [_i];  
    }

    function getAllTweets(address _owner) public view returns (Tweet[] memory) {
        return tweets[_owner];  
    }
}